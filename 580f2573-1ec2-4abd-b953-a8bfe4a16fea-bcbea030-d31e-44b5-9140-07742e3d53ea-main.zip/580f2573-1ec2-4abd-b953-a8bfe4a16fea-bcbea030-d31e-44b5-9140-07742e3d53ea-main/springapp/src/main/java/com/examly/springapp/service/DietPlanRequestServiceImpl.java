package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.config.UserDetailsServiceImpl;
import com.examly.springapp.model.DietPlanRequest;
import com.examly.springapp.repository.DietPlanRequestRepo;

@Service("dietPlanRequestServiceImpl")
public class DietPlanRequestServiceImpl implements DietPlanRequestService {

    @Autowired
    DietPlanRequestRepo dietPlanRequestRepo;

        private static final Logger logger = LoggerFactory.getLogger(DietPlanRequestServiceImpl.class);


    @Override
    public DietPlanRequest addDietPlanRequest(DietPlanRequest dietPlanRequest) {
        logger.info("inside addDietPlanRequest");
        return dietPlanRequestRepo.save(dietPlanRequest);
    }

    @Override
    public List<DietPlanRequest> getAllDietPlanRequests() {
        logger.info("inside getAllDietPlanRequests");
        return dietPlanRequestRepo.findAll();
    }
    
    @Override
    public List<DietPlanRequest> getAllDietPlanRequestsByUserId(Long userId) {
        logger.info("inside getAllDietPlanRequestsByUserId");
        return dietPlanRequestRepo.getAllDietPlanRequestsByUserId(userId);
    }
    
    @Override
    public DietPlanRequest editDietPlanRequest(Long dietPlanRequestId, DietPlanRequest updateDietPlanRequest) {
        logger.info("inside editDietPlanRequest");
        Optional<DietPlanRequest> toBeUpdated = dietPlanRequestRepo.findById(dietPlanRequestId);
        if (toBeUpdated.isPresent()) {
            DietPlanRequest newDietPlanRequest = toBeUpdated.get();
            newDietPlanRequest.setActivityLevel(updateDietPlanRequest.getActivityLevel());
            newDietPlanRequest.setAge(updateDietPlanRequest.getAge());
            newDietPlanRequest.setCreatedAt(updateDietPlanRequest.getCreatedAt());
            newDietPlanRequest.setDietPlan(updateDietPlanRequest.getDietPlan());
            newDietPlanRequest.setGender(updateDietPlanRequest.getGender());
            newDietPlanRequest.setGoal(updateDietPlanRequest.getGoal());
            newDietPlanRequest.setHeight(updateDietPlanRequest.getHeight());
            newDietPlanRequest.setWeight(updateDietPlanRequest.getWeight());
            newDietPlanRequest.setStatus(updateDietPlanRequest.getStatus());
            return dietPlanRequestRepo.save(newDietPlanRequest);
        } else {
            return null;
        }
    }
    
    @Override
    public DietPlanRequest deleteDietPlanRequest(Long dietPlanRequestId) {
        logger.info("inside deleteDietPlanRequest");
        DietPlanRequest dietPlanRequest = dietPlanRequestRepo.findById(dietPlanRequestId).orElse(null);
        if (dietPlanRequest == null) {
            return null;
        } else {
            dietPlanRequestRepo.deleteById(dietPlanRequestId);
            return dietPlanRequest;
        }

    }

}
