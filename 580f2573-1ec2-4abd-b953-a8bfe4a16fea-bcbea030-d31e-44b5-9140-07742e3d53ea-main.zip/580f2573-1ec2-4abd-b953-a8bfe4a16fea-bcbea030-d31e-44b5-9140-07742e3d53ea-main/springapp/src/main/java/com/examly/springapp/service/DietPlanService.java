package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.DietPlan;

public interface DietPlanService {

    public DietPlan addDietPlan(DietPlan dietPlan);

    public List<DietPlan> getAllDietPlans();

    public DietPlan editDietPlan(long dietPlanId, DietPlan updatedDietPlan);

    public DietPlan deleteDietPlan(long dietPlanId);

    public DietPlan getByDietPlanById(long dietPlanId);

}
