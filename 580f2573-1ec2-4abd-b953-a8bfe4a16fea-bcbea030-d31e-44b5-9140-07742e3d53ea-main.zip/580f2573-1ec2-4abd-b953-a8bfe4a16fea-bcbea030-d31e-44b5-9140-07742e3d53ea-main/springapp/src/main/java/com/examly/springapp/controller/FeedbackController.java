package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Utils;
import com.examly.springapp.model.Feedback;
import com.examly.springapp.service.FeedbackServiceImpl;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = Utils.FRONTEND_URL,allowedHeaders = "*")
public class FeedbackController {

    @Autowired
    FeedbackServiceImpl feedbackServiceImpl;

    @GetMapping("/feedback")
    @PreAuthorize("permitAll()")
    public ResponseEntity<List<Feedback>> viewAllFeedback(){
        List<Feedback>feedbacks = feedbackServiceImpl.getAllFeedback();
        if(feedbacks!=null){
            return new ResponseEntity<>(feedbacks,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/feedback")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Feedback> addFeedback(@RequestBody Feedback feedback){
        Feedback addedFeedback = feedbackServiceImpl.addFeedback(feedback);
        if(addedFeedback!=null){
            return new ResponseEntity<>(addedFeedback,HttpStatus.CREATED);
        }
        else{
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/feedback/{feedbackId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<Feedback> deleteFeedback(@PathVariable("feedbackId") long feedbackId){
        Feedback deletedFeedback = feedbackServiceImpl.deleteFeedback(feedbackId);
        if(deletedFeedback != null){
            return new ResponseEntity<>(deletedFeedback,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(deletedFeedback,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/feedback/user/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<List<Feedback>> viewFeedbackByUserId(@PathVariable("userId") long userId){
        List<Feedback>feedbacks = feedbackServiceImpl.getAllFeedBackByUserId(userId);
        if(feedbacks!=null){
            return new ResponseEntity<>(feedbacks,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


}
