package com.examly.springapp.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Utils;
import com.examly.springapp.config.JwtUtils;
import com.examly.springapp.model.LoginDTO;
import com.examly.springapp.model.User;
import com.examly.springapp.service.UserServiceImpl;

@RestController
@CrossOrigin(origins =Utils.FRONTEND_URL,allowedHeaders = "*")
public class AuthController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Autowired
    private JwtUtils jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;


    @PostMapping("/api/register")
    public ResponseEntity<?> registerUser(@RequestBody User user){
        System.out.println("************Register : "+user);
        userServiceImpl.registerUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(true);
    }

    @PostMapping("/api/login")
    public LoginDTO authenticateAndGetToken(@RequestBody User user){
        System.out.println("inside login controller");
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
        if(authentication.isAuthenticated()){
            LoginDTO loginDto=new LoginDTO();
            loginDto.setEmail(user.getEmail());
            loginDto.setToken(jwtService.GenerateToken(user.getEmail()));
            String role=userServiceImpl.getRoleByEmail(user.getEmail());
            long userId=userServiceImpl.getIdByEmail(user.getEmail());
            String username=userServiceImpl.getUsernameByEmail(user.getEmail());
            loginDto.setRole(role);
            loginDto.setUserId(userId);
            loginDto.setUsername(username);
            System.out.println("role-------------------------->"+user.getRole());
            return loginDto;
        }
         else {
            throw new UsernameNotFoundException("invalid user request..!!");
        }
    }
    
}
