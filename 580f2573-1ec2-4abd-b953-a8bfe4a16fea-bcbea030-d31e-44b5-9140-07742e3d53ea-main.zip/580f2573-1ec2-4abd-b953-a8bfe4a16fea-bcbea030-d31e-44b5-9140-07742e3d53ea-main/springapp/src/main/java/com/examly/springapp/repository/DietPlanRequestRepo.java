package com.examly.springapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.DietPlanRequest;

@Repository
public interface DietPlanRequestRepo extends JpaRepository<DietPlanRequest,Long> {
    
    @Query("select p from DietPlanRequest p where p.user.userId=?1")
    public List<DietPlanRequest> getAllDietPlanRequestsByUserId(Long userId);

}
