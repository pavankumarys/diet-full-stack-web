package com.examly.springapp.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "diet_plan_request")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DietPlanRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long dietPlanRequestId;
    private int age;
    private double weight;
    private double height;
    private String gender;
    private String activityLevel;
    private String goal;
    private String medicalConditions;
    private LocalDate createdAt;
    private String status;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    @ManyToOne
    @JoinColumn(name = "diet_plan_id")
    private DietPlan dietPlan;
}
