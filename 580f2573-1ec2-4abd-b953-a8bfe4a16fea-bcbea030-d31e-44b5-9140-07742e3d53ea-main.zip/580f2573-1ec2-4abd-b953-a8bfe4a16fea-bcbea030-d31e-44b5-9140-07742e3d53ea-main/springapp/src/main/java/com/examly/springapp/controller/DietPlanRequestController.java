package com.examly.springapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Utils;
import com.examly.springapp.model.DietPlanRequest;
import com.examly.springapp.service.DietPlanRequestServiceImpl;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = Utils.FRONTEND_URL,allowedHeaders = "*")
public class DietPlanRequestController {

    @Autowired
    private DietPlanRequestServiceImpl dietPlanRequestServiceImpl;

    Logger logger=LoggerFactory.getLogger(DietPlanRequestController.class);
    
    @PostMapping("/dietplanrequests")
    @PreAuthorize("hasAuthority('user')")
    public ResponseEntity<DietPlanRequest> addDietPlanRequest(@RequestBody DietPlanRequest dietPlanRequest){
        System.out.println("inside add dietplan");
        logger.info("inside add dietplan---------------------------------------");
        DietPlanRequest addedDietPlan=dietPlanRequestServiceImpl.addDietPlanRequest(dietPlanRequest);
        if(addedDietPlan!=null){
            return new ResponseEntity<>(addedDietPlan,HttpStatus.CREATED);
        }else{
            return new ResponseEntity<>(addedDietPlan,HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("/dietplanrequests")
    @PreAuthorize("permitAll()")
    public ResponseEntity<List<DietPlanRequest>> viewAllDietPlanRequests(){
        List<DietPlanRequest> dietPlanRequest=dietPlanRequestServiceImpl.getAllDietPlanRequests();
        if(dietPlanRequest!=null){
            return new ResponseEntity<>(dietPlanRequest,HttpStatus.OK);
        }else{
            return new ResponseEntity<>(dietPlanRequest,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/dietplanrequests/user/{userId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<List<DietPlanRequest>> viewDietPlanRequestsById(@PathVariable("userId") Long userId ){
        List<DietPlanRequest> dietPlanRequest=dietPlanRequestServiceImpl.getAllDietPlanRequestsByUserId(userId);
        if(dietPlanRequest!=null){
            return new ResponseEntity<>(dietPlanRequest,HttpStatus.OK);
        }else{
            return new ResponseEntity<>(dietPlanRequest,HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PutMapping("/dietplanrequests/{dietPlanRequestId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<DietPlanRequest> editDietPlanRequestStatus(@RequestBody DietPlanRequest dietPlanRequest,@PathVariable("dietPlanRequestId") long dietPlanRequestId){
        DietPlanRequest updatedDietPlanRequest=dietPlanRequestServiceImpl.editDietPlanRequest(dietPlanRequestId, dietPlanRequest);
        if(updatedDietPlanRequest!=null){
            return new ResponseEntity<>(updatedDietPlanRequest,HttpStatus.OK);
        }else{
            return new ResponseEntity<>(updatedDietPlanRequest,HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @DeleteMapping("/dietplanrequests/{dietPlanRequestId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<DietPlanRequest> deleteDietPlanRequestByUserId(@PathVariable("dietPlanRequestId") long dietPlanRequestId){
        DietPlanRequest deletedDietPlanRequest=dietPlanRequestServiceImpl.deleteDietPlanRequest(dietPlanRequestId);
        if(deletedDietPlanRequest!=null){
            return new ResponseEntity<>(deletedDietPlanRequest,HttpStatus.OK);
        }else{
            return new ResponseEntity<>(deletedDietPlanRequest,HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    
}
