package com.examly.springapp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class GlobalExceptionAdvice {


    @ExceptionHandler(AuthenticationException.class )
    public ResponseEntity<String> handleAuthenticationException(AuthenticationException ex) {
           String errmsg="Invalid Credential!! Authentication Failed";
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errmsg);
    }

    @ExceptionHandler(UsernameNotFoundException.class)
    @ResponseStatus(code = HttpStatus.NOT_FOUND)
    public String handleUsernameNotFoundException(UsernameNotFoundException usernameNotFoundException){
        return usernameNotFoundException.getMessage();
    }
    

    @ExceptionHandler(UserExistsException.class)
    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleUserNotFoundException(UserExistsException userExistsException){
        return userExistsException.getMessage();
    }

    @ExceptionHandler(DietPlanAlreadyExistsException.class)
    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    public String DietPlanAlreadyExistsException(DietPlanAlreadyExistsException dietPlanAlreadyExistsException){
        return dietPlanAlreadyExistsException.getMessage();
    }


    
}
