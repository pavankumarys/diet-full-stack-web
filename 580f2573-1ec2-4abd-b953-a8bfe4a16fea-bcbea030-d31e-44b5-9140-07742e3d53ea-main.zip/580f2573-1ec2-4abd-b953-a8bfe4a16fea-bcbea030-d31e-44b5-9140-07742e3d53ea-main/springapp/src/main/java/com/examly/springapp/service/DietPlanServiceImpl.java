package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.DietPlan;
import com.examly.springapp.repository.DietPlanRepo;

@Service("dietPlanServiceImpl")
public class DietPlanServiceImpl implements DietPlanService {

    private static final Logger logger = LoggerFactory.getLogger(DietPlanServiceImpl.class);

    @Autowired
    DietPlanRepo dietPlanRepo;

    @Override
    public DietPlan addDietPlan(DietPlan dietPlan) {
        logger.info("inside addDietPlan");
        return dietPlanRepo.save(dietPlan);
    }
    
    @Override
    public List<DietPlan> getAllDietPlans() {
        logger.info("inside getAllDietPlans");
        return dietPlanRepo.findAll();
    }
    
    @Override
    public DietPlan editDietPlan(long dietPlanId, DietPlan updatedDietPlan) {
        logger.info("inside editDietPlan");
        Optional<DietPlan> toBeUpdated = dietPlanRepo.findById(dietPlanId);
        if (toBeUpdated.isPresent()) {
            DietPlan newdietPlan = toBeUpdated.get();
            newdietPlan.setPlanName(updatedDietPlan.getPlanName());
            newdietPlan.setDescription(updatedDietPlan.getDescription());
            newdietPlan.setDuration(updatedDietPlan.getDuration());
            newdietPlan.setCreatedAt(updatedDietPlan.getCreatedAt());
            return dietPlanRepo.save(newdietPlan);
        } else {
            return null;
        }
    }
    
    @Override
    public DietPlan deleteDietPlan(long dietPlanId) {
        logger.info("inside deleteDietPlan");
        DietPlan dietPlan = dietPlanRepo.findById(dietPlanId).orElse(null);
        if (dietPlan == null) {
            return null;
        } else {
            dietPlanRepo.deleteById(dietPlanId);
            return dietPlan;
        }
    }
    
    @Override
    public DietPlan getByDietPlanById(long dietPlanId) {
        logger.info("inside getByDietPlanById");
        return dietPlanRepo.findById(dietPlanId).orElse(null);
    }

}
