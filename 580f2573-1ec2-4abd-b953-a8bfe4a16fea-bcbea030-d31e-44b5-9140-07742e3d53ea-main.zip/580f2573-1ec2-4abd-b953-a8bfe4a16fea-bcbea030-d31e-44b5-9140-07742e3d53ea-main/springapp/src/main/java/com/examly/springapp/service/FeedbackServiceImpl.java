package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Feedback;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.FeedbackRepo;
import com.examly.springapp.repository.UserRepo;

@Service("feedbackServiceImpl")
public class FeedbackServiceImpl implements FeedbackService {

    private static final Logger logger = LoggerFactory.getLogger(FeedbackServiceImpl.class);

    @Autowired
    FeedbackRepo feedbackRepo;

    @Autowired
    UserRepo userRepo;

    public Feedback addFeedback(Feedback feedback) {
        logger.info("inside addFeedback");
        return feedbackRepo.save(feedback);
    }
    
    public List<Feedback> getAllFeedback() {
        logger.info("inside getAllFeedback");
        return feedbackRepo.findAll();
    }
    
    public List<Feedback> getAllFeedBackByUserId(Long userId) {
        logger.info("inside getAllFeedBackByUserId");
        Optional<User> user = userRepo.findById(userId);
        if (user.isPresent()) {
            return feedbackRepo.findByUserId(userId);
        } else {
            return null;
        }
    }
    
    public Feedback editFeedback(Long feedbackId, Feedback updatedFeedback) {
        logger.info("inside editFeedback");
        Optional<Feedback> toBeUpdated = feedbackRepo.findById(feedbackId);
        if (toBeUpdated.isPresent()) {
            Feedback newFeedback = toBeUpdated.get();
            newFeedback.setFeedbackText(updatedFeedback.getFeedbackText());
            newFeedback.setDate(updatedFeedback.getDate());
            return feedbackRepo.save(newFeedback);
        } else {
            return null;
        }
    }
    
    public Feedback deleteFeedback(Long feedbackId) {
        logger.info("inside deleteFeedback");
        Feedback feedBack = feedbackRepo.findById(feedbackId).orElse(null);
        if (feedBack != null) {
            feedbackRepo.deleteById(feedbackId);
            return feedBack;
        } else {
            return null;
        }
    }

}
