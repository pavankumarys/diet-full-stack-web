package com.examly.springapp.service;

import com.examly.springapp.model.User;

public interface UserService {

    public boolean registerUser(User user);

    public String getRoleByEmail(String email);

    public String getUsernameByEmail(String email);

    public long getIdByEmail(String email);

}
