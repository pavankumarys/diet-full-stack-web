package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.DietPlanRequest;

public interface DietPlanRequestService {

    DietPlanRequest addDietPlanRequest(DietPlanRequest dietPlanRequest);

    List<DietPlanRequest> getAllDietPlanRequests();

    List<DietPlanRequest> getAllDietPlanRequestsByUserId(Long userId);

    DietPlanRequest editDietPlanRequest(Long dietPlanRequestId, DietPlanRequest updateDietPlanRequest);

    DietPlanRequest deleteDietPlanRequest(Long dietPlanRequestId);

}
