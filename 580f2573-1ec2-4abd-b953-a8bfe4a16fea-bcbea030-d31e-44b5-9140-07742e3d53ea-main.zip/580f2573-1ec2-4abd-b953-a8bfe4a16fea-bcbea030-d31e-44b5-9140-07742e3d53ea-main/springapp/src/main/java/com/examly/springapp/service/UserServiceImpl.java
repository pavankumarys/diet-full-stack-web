package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.UserExistsException;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

@Service("userServiceImpl")
public class UserServiceImpl {

  @Autowired
  private UserRepo userRepo;

  @Autowired
  private PasswordEncoder passwordEncoder;

  public boolean registerUser(User user) {
    User existUser = userRepo.findByEmail(user.getEmail()).orElse(null);
    if (existUser != null) {
      throw new UserExistsException("User Already Exists");
    } else {
      user.setPassword(passwordEncoder.encode(user.getPassword()));
      userRepo.save(user);
      return true;
    }
  }

  public String getRoleByEmail(String email) {
    User user = userRepo.findByEmail(email).orElse(null);
    if (user != null) {
      return user.getRole();
    } else {
      return null;
    }
  }

  public String getUsernameByEmail(String email) {
    User user = userRepo.findByEmail(email).orElse(null);
    if (user != null) {
      return user.getUsername();
    } else {
      return null;
    }
  }

  public long getIdByEmail(String email) {
    User user = userRepo.findByEmail(email).orElse(null);
    if (user != null) {
      return user.getUserId();
    } else {
      return 0;
    }
  }

}
