package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.Feedback;

public interface FeedbackService {
    
    Feedback addFeedback(Feedback feedback);

    List<Feedback> getAllFeedback();

    List<Feedback> getAllFeedBackByUserId(Long userId);

    Feedback editFeedback(Long feedbackId, Feedback updatedFeedback);

    Feedback deleteFeedback(Long feedbackId);
}
