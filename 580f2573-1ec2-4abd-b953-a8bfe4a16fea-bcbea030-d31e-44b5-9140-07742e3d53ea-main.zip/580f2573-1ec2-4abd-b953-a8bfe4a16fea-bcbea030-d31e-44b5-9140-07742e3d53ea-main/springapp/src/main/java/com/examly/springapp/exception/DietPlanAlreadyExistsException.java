package com.examly.springapp.exception;

public class DietPlanAlreadyExistsException extends RuntimeException {
    public DietPlanAlreadyExistsException(String e){
        super(e);
    }
}
