package com.examly.springapp.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.Utils;
import com.examly.springapp.model.DietPlan;
import com.examly.springapp.service.DietPlanServiceImpl;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = Utils.FRONTEND_URL,allowedHeaders = "*")
public class DietPlanController {

    @Autowired
    DietPlanServiceImpl dietPlanServiceImpl;

    @GetMapping("/dietplan")
    @PreAuthorize("permitAll()")
    public ResponseEntity<List<DietPlan>> viewAllDietPlan(){
        List<DietPlan>dietPlans = dietPlanServiceImpl.getAllDietPlans();
        if(dietPlans!=null){
            return new ResponseEntity<>(dietPlans,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping("/dietplan")
    public ResponseEntity<DietPlan> addDietPlan(@RequestBody DietPlan dietPlan){
        DietPlan addDietPlan = dietPlanServiceImpl.addDietPlan(dietPlan);
        if(addDietPlan!=null){
            return new ResponseEntity<>(addDietPlan,HttpStatus.CREATED);  
        } 
        else{
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  
        }
    }
    
    @GetMapping("/dietplan/{dietplanId}")
    @PreAuthorize("permitAll()")
    public ResponseEntity<DietPlan> viewByDietPlanId(@PathVariable("dietplanId") long dietplanId){
        DietPlan dietPlan = dietPlanServiceImpl.getByDietPlanById(dietplanId);
        if(dietPlan!=null){
            return new ResponseEntity<>(dietPlan,HttpStatus.OK);  
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);  
        }
    }
    
    @PutMapping("/dietplan/{dietplanId}")
    @PreAuthorize("hasAuthority('admin')")
    public ResponseEntity<DietPlan> editDietPlan(@PathVariable("dietplanId") long dietplanId,@RequestBody DietPlan dietPlan){
        DietPlan editDietPlan = dietPlanServiceImpl.editDietPlan(dietplanId, dietPlan);
        if(editDietPlan!=null){
            return new ResponseEntity<>(editDietPlan,HttpStatus.OK);  
        }
        else{
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);  
        }
    }

    @DeleteMapping("/dietplan/{dietplanId}")
    @PreAuthorize("hasAuthority('admin')")
    public ResponseEntity<DietPlan> deleteDietPlanById(@PathVariable("dietplanId") long dietplanId){
        DietPlan dietPlan = dietPlanServiceImpl.deleteDietPlan(dietplanId);
        if(dietPlan!=null){
            return new ResponseEntity<>(dietPlan,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }





}
