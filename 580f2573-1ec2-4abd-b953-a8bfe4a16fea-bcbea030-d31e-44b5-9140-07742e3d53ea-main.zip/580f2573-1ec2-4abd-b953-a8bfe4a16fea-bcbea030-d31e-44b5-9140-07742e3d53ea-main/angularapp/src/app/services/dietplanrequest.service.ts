import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DietPlanRequest } from '../models/dietplanrequests.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DietplanrequestService {

  public apiUrl=environment.backendUrl;
  constructor(private httpclient:HttpClient) { }

  public addDietPlanRequest(data:DietPlanRequest):Observable<any>{
    console.log("inside angular add diet plan")
    return this.httpclient.post(this.apiUrl+"api/dietplanrequests",data);
  }

  public getAppliedPlans(userId:string):Observable<any>{
    return this.httpclient.get(this.apiUrl+"api/dietplanrequests/user/"+userId);
  }

  public deletePlanApplication(requestedId:string):Observable<any>{
    return this.httpclient.delete(this.apiUrl+"api/dietplanrequests/"+requestedId);
  }

  public getAllPlanRequests():Observable<any>{
    return this.httpclient.get(this.apiUrl+"api/dietplanrequests");
  }

  public updatePlanStatus(id:string,planApplication:DietPlanRequest):Observable<any>{
    return this.httpclient.put(this.apiUrl+"api/dietplanrequests/"+id,planApplication);
  }


}
