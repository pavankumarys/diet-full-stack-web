import { Injectable } from '@angular/core';
import { Feedback } from '../models/feedback.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  
  public apiUrl=environment.backendUrl;
  
  constructor(private http:HttpClient) { }

  public sendFeedback(feedback:Feedback):Observable<any>{
    return this.http.post(this.apiUrl+"api/feedback",feedback);
  }

  public getAllFeedbackByUserId(userId:string):Observable<any>{
    return this.http.get(this.apiUrl+"api/feedback/user/"+userId);
  }

  public deleteFeedback(feedbackId:string):Observable<any>{
    return this.http.delete(this.apiUrl+"api/feedback/"+feedbackId);
  }

  public getFeedbacks():Observable<any>{
     return this.http.get(this.apiUrl+"api/feedback");
  }
}
