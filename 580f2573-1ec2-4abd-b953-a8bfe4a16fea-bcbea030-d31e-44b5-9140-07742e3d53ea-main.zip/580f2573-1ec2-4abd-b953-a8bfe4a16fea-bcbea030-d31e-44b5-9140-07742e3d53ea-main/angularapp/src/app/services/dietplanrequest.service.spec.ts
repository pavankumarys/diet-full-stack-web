import { TestBed } from '@angular/core/testing';

import { DietplanrequestService } from './dietplanrequest.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('DietplanrequestService', () => {
  let service: DietplanrequestService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(DietplanrequestService);
  });

  fit('frontend_dietplanrequest service should be created', () => {
    expect(service).toBeTruthy();
  });
});
