import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DietPlan } from '../models/dietplan.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DietplanService {

  public apiUrl=environment.backendUrl;

  constructor(private httpClient : HttpClient ) { }

  public getAllDietPlans():Observable<any>
  {
    console.log("inside get all plans service")
    return this.httpClient.get(this.apiUrl+"api/dietplan");
  }

  public deleteDietPlan(dietPlanId:string):Observable<any>
  {
    return this.httpClient.delete(this.apiUrl + "api/dietplan/" + dietPlanId);
  }

  public getDietPlanById(id:string):Observable<any>
  {
    return this.httpClient.get(this.apiUrl + "api/dietplan/" + id );
  }

  public addDietPlan(dietplan:DietPlan):Observable<any>
  {
    return this.httpClient.post(this.apiUrl+"api/dietplan",dietplan);
  }

  public updateDietPlan( id:string , dietplan : DietPlan):Observable<any>
  {
    return this.httpClient.put( this.apiUrl+"api/dietplan/"+id , dietplan);
  }

  public getAppliedDietPlans(userId:string):Observable<any>
  {
    return this.httpClient.get(this.apiUrl + "api/dietplanrequests/user/" + userId) ;
  }
}
