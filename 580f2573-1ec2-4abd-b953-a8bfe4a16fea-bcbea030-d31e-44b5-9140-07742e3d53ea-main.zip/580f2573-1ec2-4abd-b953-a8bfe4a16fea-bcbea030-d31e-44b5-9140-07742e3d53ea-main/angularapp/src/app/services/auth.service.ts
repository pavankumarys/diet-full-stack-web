import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';
import { Observable, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public apiUrl = environment.backendUrl;
  private isLoggedInSubject = new BehaviorSubject<boolean>(false);

  constructor(private httpClient:HttpClient) { }

  public register(user: User):Observable<any> {
    return this.httpClient.post(this.apiUrl + "api/register", user);
  }

  public login(user: User):Observable<any> {
    return this.httpClient.post(this.apiUrl + "api/login", user);
  }

  setLoginStatus(status:boolean) {
    this.isLoggedInSubject.next(status);
  }

  getLoginStatus():Observable<boolean> {
    return this.isLoggedInSubject.asObservable();
  }
}
