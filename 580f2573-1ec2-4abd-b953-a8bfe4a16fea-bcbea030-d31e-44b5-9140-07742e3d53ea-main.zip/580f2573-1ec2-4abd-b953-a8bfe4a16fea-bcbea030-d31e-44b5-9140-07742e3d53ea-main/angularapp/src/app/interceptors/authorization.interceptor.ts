import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
@Injectable()
export class AuthorizationInterceptor implements HttpInterceptor {

  constructor(private router:Router) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.log("Visited URL: " + request.url);
    
    const email = localStorage.getItem('email');
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role')
    
    
    
    if (email && token) {
      console.log("Inside if block, setting headers");
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    } else {
      console.error("Token or email not found in localStorage");
    }
    
    console.log("Request headers: ", request.headers);
    
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
          // Handle unauthorized error
          this.router.navigate(['/login']);
        } else if (error.status === 404) {
          // Handle not found error
          this.router.navigate(['/error']);
        }
        return throwError(error);
      })
    );
  }
}