import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestedplanComponent } from './requestedplan.component';

describe('RequestedplanComponent', () => {
  let component: RequestedplanComponent;
  let fixture: ComponentFixture<RequestedplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestedplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestedplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
