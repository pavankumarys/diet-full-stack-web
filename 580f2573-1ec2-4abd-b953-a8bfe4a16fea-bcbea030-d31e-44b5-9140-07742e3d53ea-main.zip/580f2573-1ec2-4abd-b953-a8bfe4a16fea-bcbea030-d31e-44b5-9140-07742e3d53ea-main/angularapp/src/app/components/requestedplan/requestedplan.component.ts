import { Component, OnInit } from '@angular/core';
import { DietPlanRequest } from 'src/app/models/dietplanrequests.model';
import { DietplanrequestService } from 'src/app/services/dietplanrequest.service';

@Component({
  selector: 'app-requestedplan',
  templateUrl: './requestedplan.component.html',
  styleUrls: ['./requestedplan.component.css']
})
export class RequestedplanComponent implements OnInit {

  constructor(private service:DietplanrequestService) { }

  
  requests:DietPlanRequest[]=[];
  showMore:DietPlanRequest;
  show:Boolean=false;
  searchTerm:string;
  isloading:boolean;
  
  ngOnInit(): void {
    this.getAllRequestedPlans();
  }
  getAllRequestedPlans(){
    this.isloading=true
    this.service.getAllPlanRequests().subscribe(data=>{
      this.requests = data;
      console.log(JSON.stringify(data));
      this.isloading=false;
    })
  }

  searchDietPlan(){
    if(this.searchTerm===""){
      this.getAllRequestedPlans()
    }else{
      this.requests=this.requests.filter(data=>JSON.stringify(data).toLowerCase().includes(this.searchTerm.toLowerCase()));
    }
  }

  more(request:DietPlanRequest){
    this.showMore={...request};
    this.show=true;
  }
  closeModal(){
    this.show = false;
  }
  status(request:DietPlanRequest){
    let Id:string  = request.dietPlanRequestId.toString();
    request.status = "Approved";
    console.log(request);
    this.service.updatePlanStatus(Id,request).subscribe(data=>{
      this.getAllRequestedPlans();
    });
  }
  reject(request){
    let Id:string  = request.dietPlanRequestId.toString();
    request.status = "Rejected";
    console.log(request);
    this.service.updatePlanStatus(Id,request).subscribe(data=>{
      this.getAllRequestedPlans();
    });
  }
}
