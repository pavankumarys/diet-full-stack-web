import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  errorMessage: string | null = null;

  constructor(private builder: FormBuilder, private service: AuthService, private router: Router) {
    this.loginForm = builder.group({
      email: builder.control("", [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$")]),
      password: builder.control("", Validators.required)
    });
  }

  public login() {
    if (this.loginForm.valid) {
      this.service.login(this.loginForm.value).subscribe(data => {
          let myToken: string = data.token;
          console.log(myToken);
          localStorage.setItem('token', myToken);
          localStorage.setItem("email", data.email);
          localStorage.setItem("role", data.role);
          localStorage.setItem("userId", data.userId);
          localStorage.setItem("username", data.username);
          console.log("user name _------------------>" + data.userName);
          let role = data.role;
          this.service.setLoginStatus(true);
          Swal.fire({
            title: "Successfully Logged in!",
            icon: "success"
          }).then((result) => {
            if (result.isConfirmed) {
              this.router.navigate(['/home'])
            }
          });
        },
        err => {
          this.errorMessage = "*Invalid email or password. Please try again.";
        }
      );
    }
  }

  ngOnInit(): void { }
}
