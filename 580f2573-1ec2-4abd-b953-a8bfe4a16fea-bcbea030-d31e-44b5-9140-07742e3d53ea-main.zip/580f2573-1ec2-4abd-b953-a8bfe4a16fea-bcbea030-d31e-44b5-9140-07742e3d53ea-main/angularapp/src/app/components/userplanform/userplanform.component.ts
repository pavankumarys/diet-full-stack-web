import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DietPlanRequest } from 'src/app/models/dietplanrequests.model';
import { DietplanrequestService } from 'src/app/services/dietplanrequest.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-userplanform',
  templateUrl: './userplanform.component.html',
  styleUrls: ['./userplanform.component.css']
})
export class UserplanformComponent implements OnInit {

  planForm:FormGroup;
  dietPlanId:number
  newPlan:DietPlanRequest;
  flag:boolean=false;

  constructor(private builder:FormBuilder,private service:DietplanrequestService,private activatedRoute:ActivatedRoute,private router:Router) {
    this.planForm = builder.group({
      age:builder.control("",[Validators.required,Validators.min(1),Validators.max(150)]),
      weight:builder.control("",[Validators.required,Validators.min(1),Validators.max(200)]),
      height:builder.control("",[Validators.required,Validators.min(49),Validators.max(300)]),
      gender:builder.control("",Validators.required),
      activityLevel:builder.control("",Validators.required),
      goal:builder.control("",Validators.required),
      medicalConditions:builder.control("",Validators.required)
    });
     this.dietPlanId=parseInt(activatedRoute.snapshot.queryParamMap.get('dietPlanId'))
   }

   public get age(){
    return this.planForm.get("age");
   }
   public get weight(){
    return this.planForm.get("weight");
   }
   public get height(){
    return this.planForm.get("height");
   }
   public get gender(){
    return this.planForm.get("gender");
   }
   public get activityLevel(){
    return this.planForm.get("activityLevel");
   }
   public get goal(){
    return this.planForm.get("goal");
   }
   public get medicalConditions(){
    return this.planForm.get("medicalConditions");
   }


  ngOnInit(): void {
  }

  addDietPlanApplication(){
    console.log("inside add diet plan angular")
    if(this.planForm.invalid){
      this.flag=true;
    }
    else
    {
    
    console.log("diet plan id --------------------------------------->",this.dietPlanId);
    let userId=parseInt(localStorage.getItem("userId"))
    console.log("user id ----------------------------------------->",userId);
    
    let plan:DietPlanRequest = {...this.planForm.value};
    plan.user={userId:userId}
    plan.dietPlan={dietPlanId:this.dietPlanId};
    plan.createdAt= new Date();
    plan.status = "Pending" ;
    this.service.addDietPlanRequest(plan).subscribe(data=>{
      this.newPlan=data;
      Swal.fire({
        title: "Successfully added!",
        icon: "success"
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(["/userviewplan"])
        }
      });
    });
  }
  }

  goBack()
  {
    this.router.navigate(["/userviewplan"]);
  }

}
