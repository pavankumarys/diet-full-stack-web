import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserplanformComponent } from './userplanform.component';

describe('UserplanformComponent', () => {
  let component: UserplanformComponent;
  let fixture: ComponentFixture<UserplanformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserplanformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserplanformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
