import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminaddplanComponent } from './adminaddplan.component';

describe('AdminaddplanComponent', () => {
  let component: AdminaddplanComponent;
  let fixture: ComponentFixture<AdminaddplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminaddplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminaddplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
