import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DietPlan } from 'src/app/models/dietplan.model';
import { DietplanService } from 'src/app/services/dietplan.service';
import Swal from 'sweetalert2' ; 

@Component({
  selector: 'app-adminaddplan',
  templateUrl: './adminaddplan.component.html',
  styleUrls: ['./adminaddplan.component.css']
})
export class AdminaddplanComponent implements OnInit {

  dietForm:FormGroup ;
  inValidDiet:Boolean = false ;
  newDietPlan:DietPlan ;
  AlreadyExistPlanName:Boolean = false ;
  DietPlans : DietPlan[] = [] ;

  constructor(private formBuilder : FormBuilder , private service : DietplanService ,private router : Router ) {
    this.dietForm = formBuilder.group({
      planName:formBuilder.control("",Validators.required),
      description:formBuilder.control("",Validators.required),
      duration:formBuilder.control("",[Validators.required,Validators.min(1),Validators.max(365)])
    });
  }

  ngOnInit(): void {
    this.getAllDietPlans();
  }

  public get planName()
  {
    return this.dietForm.get("planName");
  }

  public get description()
  {
    return this.dietForm.get("description");
  }

  public get duration()
  {
    return this.dietForm.get("duration");
  }

  public getAllDietPlans()
  {
    this.service.getAllDietPlans().subscribe(data=>{
      this.DietPlans = data ;
    });
  }

  public addNewPlan()
  {
    if(this.dietForm.invalid)
    {
      this.inValidDiet = true ;
      return ;
    }
    else
    {

      this.newDietPlan = this.dietForm.value ;
      let name = this.newDietPlan.planName.trim() ;
      let decision = this.DietPlans.find(plan=>plan.planName.toLowerCase() == name.toLowerCase() );
      if(decision)
      {
        this.AlreadyExistPlanName = true ;
        return ;
      }
      else
      {
        this.newDietPlan.createdAt = new Date();
        this.service.addDietPlan(this.newDietPlan).subscribe(data=>{
          this.newDietPlan = null ;
          this.dietForm.reset();
          Swal.fire({
            icon: 'success',
            title: 'Diet Plan Added',
            text: 'Your new diet plan has been successfully added!',
          }).then(() => {
            this.router.navigate(['/viewdietplan']);
          });
        })
      }
    }
  }



}
