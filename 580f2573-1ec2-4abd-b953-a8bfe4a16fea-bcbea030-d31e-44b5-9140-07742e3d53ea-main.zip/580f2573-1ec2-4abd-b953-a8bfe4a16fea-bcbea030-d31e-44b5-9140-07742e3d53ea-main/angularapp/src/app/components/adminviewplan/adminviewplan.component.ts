import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DietPlan } from 'src/app/models/dietplan.model';
import { DietPlanRequest } from 'src/app/models/dietplanrequests.model';
import { DietplanService } from 'src/app/services/dietplan.service';
import { DietplanrequestService } from 'src/app/services/dietplanrequest.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-adminviewplan',
  templateUrl: './adminviewplan.component.html',
  styleUrls: ['./adminviewplan.component.css']
})
export class AdminviewplanComponent implements OnInit {

  dietplans: DietPlan[] = [];
  searchTerm: string;
  isloading: boolean;

  constructor(private dietplanService: DietplanService, private service: DietplanrequestService,private router:Router) { }

  ngOnInit(): void {
    this.getAllDietPlans();
  }

  public getAllDietPlans() {
    this.isloading = true
    this.dietplanService.getAllDietPlans().subscribe(data => {
      this.dietplans = data;
      this.isloading = false;
    })
  }

  searchDietPlan() {
    if (this.searchTerm === "") {
      this.getAllDietPlans()
    } else {
      this.dietplans = this.dietplans.filter(data => JSON.stringify(data).toLowerCase().includes(this.searchTerm.toLowerCase()));
    }
  }

  public deleteDietPlan(id: string) {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.dietplanService.deleteDietPlan(id).subscribe(data => {
          this.getAllDietPlans();
          Swal.fire({
            title: "Deleted!",
            text: "Diet Plan has been deleted.",
            icon: "success"
          });
        },
          err => {
            if (err.status === 401) {
              Swal.fire({
                title: "Failed",
                text: "This can't be deleted as user has already applied for the plan!!.",
                icon: "error"
              });
              this.router.navigate(["/viewdietplan"])
            }
          }
        )
      }
    });
  }

}
