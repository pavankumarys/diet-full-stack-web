import { Component, OnInit } from '@angular/core';
import { DietPlan } from 'src/app/models/dietplan.model';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-adminviewfeedback',
  templateUrl: './adminviewfeedback.component.html',
  styleUrls: ['./adminviewfeedback.component.css']
})
export class AdminviewfeedbackComponent implements OnInit {

  user:User;
  searchTerm:string
  feedback:Feedback={feedbackId:0,feedbackText:"",user:null};
  constructor(private service:FeedbackService) { }


  
  feedbacks:Feedback[]=[]
  isloading:boolean;;

  show:boolean = false;
  showUser:User;
  ngOnInit(): void {
    this.getFeedbacks();
  }
  
  getFeedbacks(){
    this.isloading=true
    console.log("inside get feedbacks")
    this.service.getFeedbacks().subscribe(data=>{
      console.log("data is "+JSON.stringify(data));
      this.feedbacks = data;
      this.isloading=false
    })
  }
  showProfile(feedback){
    this.showUser = feedback.user;
    this.show=true;
  }

  searchFeedback(){
    if(this.searchTerm===""){
      this.getFeedbacks();
    }else{
      this.feedbacks=this.feedbacks.filter(data=>JSON.stringify(data).toLowerCase().includes(this.searchTerm.toLowerCase()));
    }
  }

  closeModal(){
    this.show = false;
  }
  
}
