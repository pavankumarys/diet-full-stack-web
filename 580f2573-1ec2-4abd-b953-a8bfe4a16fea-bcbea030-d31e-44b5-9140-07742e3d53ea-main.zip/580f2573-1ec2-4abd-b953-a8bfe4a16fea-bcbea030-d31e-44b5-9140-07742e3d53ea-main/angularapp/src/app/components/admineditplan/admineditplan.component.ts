import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DietPlan } from 'src/app/models/dietplan.model';
import { DietplanService } from 'src/app/services/dietplan.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-admineditplan',
  templateUrl: './admineditplan.component.html',
  styleUrls: ['./admineditplan.component.css']
})
export class AdmineditplanComponent implements OnInit {

  dietPlanId: string;
  dietPlanForm: FormGroup;
  DietPlans:DietPlan[] = [] ;
  AlreadyExistPlanName:boolean = false ;
  existingplanName:string ;
  inValidDiet:boolean = false ;

  constructor(
    private dietplanService: DietplanService,
    private activatedRouter: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.dietPlanId = this.activatedRouter.snapshot.queryParamMap.get("Id");
    this.getAllDietPlans();
    this.initForm();
    this.getDietPlanById();
  }

  private initForm(): void {
    this.dietPlanForm = this.fb.group({
      dietPlanId: [0],
      planName: ['', Validators.required],
      description: ['', Validators.required],
      duration: [0, [Validators.required,Validators.min(1),Validators.max(365)]],
      createdAt: [new Date()]
    });
  }

  public goBack()
  {
    this.router.navigate(['/viewdietplan']);
  }
  public get planName()
  {
    return this.dietPlanForm.get("planName");
  }

  public get description()
  {
    return this.dietPlanForm.get("description");
  }

  public get duration()
  {
    return this.dietPlanForm.get("duration");
  }

  public getAllDietPlans()
  {
    this.dietplanService.getAllDietPlans().subscribe(data=>{
      this.DietPlans = data ;
    });
  }

  public getDietPlanById(): void {
    console.log(this.dietPlanId);
    this.dietplanService.getDietPlanById(this.dietPlanId).subscribe(data => {
      this.dietPlanForm.patchValue(data);
      this.existingplanName = this.dietPlanForm.get('planName').value ;
    });
  }

  public updateDietPlan(): void {
    
    if(this.dietPlanForm.invalid)
    {
      this.inValidDiet = true ;
      return ;
    }
    else
    {

      let name = this.dietPlanForm.get('planName').value.trim();
      let decision = this.DietPlans.find(plan=>plan.planName.toLowerCase() == name.toLowerCase() );
      if( decision && (this.existingplanName != name ))
      {
        this.AlreadyExistPlanName = true ;
        return ;
      }
      else
      {
      this.dietplanService.updateDietPlan(this.dietPlanId, this.dietPlanForm.value).subscribe(data => {
        // this.router.navigate(['/viewdietplan']);
        Swal.fire({
          title: "Diet Plan has been updated",
          icon: "success"
        }).then((result) => {
          if (result.isConfirmed) {
            this.router.navigate(['/viewdietplan']);
          }
        });
      });
    }
  }
  }
}