import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmineditplanComponent } from './admineditplan.component';

describe('AdmineditplanComponent', () => {
  let component: AdmineditplanComponent;
  let fixture: ComponentFixture<AdmineditplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdmineditplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmineditplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
