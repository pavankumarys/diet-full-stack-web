import { Component, OnInit } from '@angular/core';
import { DietPlan } from 'src/app/models/dietplan.model';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import Swal from 'sweetalert2'; 

@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {
 
  feedbacks:Feedback[]=[];
  searchTerm:string
  isLoading:boolean
  constructor(private service:FeedbackService) { }
  userId:string = parseInt(localStorage.getItem('userId')).toString() ;
  ngOnInit(): void {
     this.getAllFeedbacks();
     
  }
 
  public getAllFeedbacks(){
    this.isLoading=true;
    this.service.getAllFeedbackByUserId(this.userId).subscribe(data=>{
      this.feedbacks = data;
      this.isLoading=false;
    })
   
  }

  searchFeedbacks(){
    if(this.searchTerm===""){
      this.getAllFeedbacks();
    }else{
      this.feedbacks=this.feedbacks.filter(data=>JSON.stringify(data).toLowerCase().includes(this.searchTerm.toLowerCase()));
    }
  }

  public deleteFeedback(feedbackId:string){
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.service.deleteFeedback(feedbackId).subscribe(data=>{
          this.getAllFeedbacks();
        })
        Swal.fire({
          title: "Deleted!",
          text: "Feedback has been deleted.",
          icon: "success"
        });
      }
    });
  }
 
}
