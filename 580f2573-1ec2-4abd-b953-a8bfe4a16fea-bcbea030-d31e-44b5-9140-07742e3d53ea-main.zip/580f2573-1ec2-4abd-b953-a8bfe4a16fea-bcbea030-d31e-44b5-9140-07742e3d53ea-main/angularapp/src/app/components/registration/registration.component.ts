import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  errorMessage: string | null = null;
  
  registerForm:FormGroup;

  constructor(private builder:FormBuilder,private service:AuthService,private router:Router) {
     this.registerForm=builder.group({
      username: builder.control("",Validators.required),
      email: builder.control("",[Validators.required,Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$")]),
      password: builder.control("",[Validators.required,Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$')]),
      confirmpassword: builder.control("",Validators.required),
      mobileNumber: builder.control("",[Validators.required,Validators.pattern(/^\d{10}$/)]),
      role: builder.control("",Validators.required)
     },{validators:this.passwordMatchValidator})
   }

   passwordMatchValidator(form:FormGroup){
    return form.get('password').value===form.get('confirmpassword').value?null:{mismatch:true};
   }

   public register(){
     console.log("in register component");
    if(this.registerForm.valid){
      console.log("in register component"); 
      this.service.register(this.registerForm.value).subscribe(data=>{
        this.router.navigate(['/login'])
      },
      err => {
        if (err.status === 500) {
          Swal.fire({
            title: "User already exists",
            text: "please try with different email.",
            icon: "error"

          });
          this.router.navigate(["/register"])
        }
      }
      );
    }
   }
  ngOnInit(): void {
  }

  

}
