import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserappliedplanComponent } from './userappliedplan.component';

describe('UserappliedplanComponent', () => {
  let component: UserappliedplanComponent;
  let fixture: ComponentFixture<UserappliedplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserappliedplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserappliedplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
