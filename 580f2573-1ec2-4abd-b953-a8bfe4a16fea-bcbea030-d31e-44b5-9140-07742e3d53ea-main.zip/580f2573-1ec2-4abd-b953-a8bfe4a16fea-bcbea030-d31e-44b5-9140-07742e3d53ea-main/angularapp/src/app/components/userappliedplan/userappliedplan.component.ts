import { Component, OnInit } from '@angular/core';
import { DietPlanRequest } from 'src/app/models/dietplanrequests.model';
import { DietplanService } from 'src/app/services/dietplan.service';
import { DietplanrequestService } from 'src/app/services/dietplanrequest.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-userappliedplan',
  templateUrl: './userappliedplan.component.html',
  styleUrls: ['./userappliedplan.component.css']
})
export class UserappliedplanComponent implements OnInit {

  appliedDietPlans: DietPlanRequest[] = [];
  searchTerm:string
  isloading:boolean;


  constructor(private service: DietplanService,private dietplanrequestservice : DietplanrequestService) { }

  ngOnInit(): void {
    this.getAllDietPlanRequest();
  }

  public getAllDietPlanRequest() {
    this.isloading=true
    this.service.getAppliedDietPlans(localStorage.getItem('userId')).subscribe(data => {
      this.appliedDietPlans = data;
      this.isloading=false
    });
  }

  searchDietPlan(){
    if(this.searchTerm===""){
      this.getAllDietPlanRequest()
    }else{
      this.appliedDietPlans=this.appliedDietPlans.filter(data=>JSON.stringify(data).toLowerCase().includes(this.searchTerm.toLowerCase()));
    }
  }

  public deleteDietPlanRequest(Id:string)
  {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.dietplanrequestservice.deletePlanApplication(Id).subscribe(data=>{
          this.getAllDietPlanRequest();
          Swal.fire({
            title: "Deleted!",
            text: "Diet Plan Request has been deleted.",
            icon: "success"
          });
        })
      }
    });
  }

  

}
