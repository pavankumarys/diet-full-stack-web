import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DietPlan } from 'src/app/models/dietplan.model';
import { DietPlanRequest } from 'src/app/models/dietplanrequests.model';
import { DietplanService } from 'src/app/services/dietplan.service';
import { DietplanrequestService } from 'src/app/services/dietplanrequest.service';

@Component({
  selector: 'app-userviewplan',
  templateUrl: './userviewplan.component.html',
  styleUrls: ['./userviewplan.component.css']
})
export class UserviewplanComponent implements OnInit {
  dietPlans: DietPlan[] = [];
  appliedDietPlans: DietPlanRequest[] = [];
  dietPlanId: number;
  applied: boolean;
  searchTerm:string;
  isLoading=true;

  constructor(private service: DietplanService, private router: Router, private dietPlanRequestService: DietplanrequestService) { }

  ngOnInit(): void {
    console.log("ngOnInit called");
    this.getAllPlans();
    this.getAllDietPlanRequest();
   
  }
  
  searchDietPlan(){
    if(this.searchTerm===""){
      this.getAllPlans();
    }else{
      this.dietPlans=this.dietPlans.filter(data=>JSON.stringify(data).toLowerCase().includes(this.searchTerm.toLowerCase()));
    }
  }
  
  public getAllDietPlanRequest() {
    this.service.getAppliedDietPlans(localStorage.getItem('userId')).subscribe(data => {
      this.appliedDietPlans = data;
      console.log("applied diet plans ----------------", JSON.stringify(data));
    });
  }
  
  public getAllPlans() {
    this.isLoading=true;
    this.service.getAllDietPlans().subscribe(data => {
      this.dietPlans = data;
      this.isLoading=false
      console.log("diet plans ----------------", JSON.stringify(data));
    });
  }

  onClick(diet: DietPlan) {
    this.router.navigate(['/useraddplan'], { queryParams: { 'dietPlanId': diet.dietPlanId } });
  }

  isApplied(Id: number): boolean {
    return this.appliedDietPlans.some(request => request.dietPlan?.dietPlanId === Id);
  }
  
}
