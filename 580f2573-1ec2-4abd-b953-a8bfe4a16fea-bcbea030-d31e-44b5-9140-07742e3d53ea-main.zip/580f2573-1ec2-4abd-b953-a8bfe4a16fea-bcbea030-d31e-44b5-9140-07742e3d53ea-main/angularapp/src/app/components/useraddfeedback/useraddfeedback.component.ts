import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {

  feedbackForm: FormGroup;
  feedback: Feedback;
  username: string;
  inValidFeedback:boolean = false ;
  
  constructor(private builder: FormBuilder, private service: FeedbackService , private router: Router) {
    this.feedbackForm = builder.group({
      feedbackText: builder.control("", Validators.required)
    })
  }


  ngOnInit(): void {
    this.service.getFeedbacks();
  }
  public get feedbackText() {
    return this.feedbackForm.get("feedbackText");
  }

  public addFeedback() {
    if (this.feedbackForm.invalid) {
      this.inValidFeedback = true ;
      return ; 
    }

    if (this.feedbackForm.valid) {
      this.feedback = this.feedbackForm.value;
      console.log("feedback user id ----------------------->",localStorage.getItem("userId"));
      this.feedback.user={userId:parseInt(localStorage.getItem("userId"))}
      this.feedback.date = new Date();
      this.service.sendFeedback(this.feedback).subscribe(() => {
        this.service.getFeedbacks();
        Swal.fire({
          title: "Feedback added!",
          icon: "success"
        }).then((result) => {
          if (result.isConfirmed) {
            this.router.navigate(['/feedback']);
          }
        });
        this.feedbackForm.reset();
        this.feedback = null ;
        
      });
    } 
  }

}
