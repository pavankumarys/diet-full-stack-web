import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-usernav',
  templateUrl: './usernav.component.html',
  styleUrls: ['./usernav.component.css']
})
export class UsernavComponent implements OnInit {

  username:string;
  constructor(private router:Router) { }


  ngOnInit(): void {
    this.username=localStorage.getItem("username");
  }

  logout() {
    console.log("------------logout called------------");
    Swal.fire({
      title: "Are you sure you want to logout?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes"
    }).then((result) => {
      if (result.isConfirmed) {
        localStorage.setItem("username", "");
        localStorage.setItem("email", "");
        localStorage.setItem("role", "");
        localStorage.setItem("userId", "");
        localStorage.setItem("token", "");
        this.router.navigate(['/login']);
      }
    });
  }
}
