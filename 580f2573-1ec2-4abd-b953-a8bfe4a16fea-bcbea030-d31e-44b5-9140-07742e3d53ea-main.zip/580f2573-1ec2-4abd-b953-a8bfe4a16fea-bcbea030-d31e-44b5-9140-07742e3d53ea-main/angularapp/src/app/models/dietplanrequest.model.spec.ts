import { DietPlanRequest } from "./dietplanrequests.model";


describe('DietPlan Model', () => {

  fit('frontend_dietplanrequest model should create an instance', () => {
    // Create a sample user object
    const dietPlanRequest: DietPlanRequest = {
        age:25
    };

    expect(dietPlanRequest).toBeTruthy();
    expect(dietPlanRequest.age).toBe(25);

  });
});