export interface Login {
    email?:string
    token?:string
    role?:string
}
