export interface DietPlan {
    dietPlanId?:number
    planName?:string
    description?:string
    duration?:number
    createdAt?:Date
}
