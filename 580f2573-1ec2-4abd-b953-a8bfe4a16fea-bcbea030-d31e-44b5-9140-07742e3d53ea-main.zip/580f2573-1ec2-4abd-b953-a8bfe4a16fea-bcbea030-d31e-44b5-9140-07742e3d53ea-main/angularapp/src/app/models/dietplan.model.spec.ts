import { DietPlan } from './dietplan.model';

describe('DietPlan Model', () => {

  fit('frontend_dietplan model should create an instance', () => {
    // Create a sample user object
    const dietPlan: DietPlan = {
        planName:'Sample'
    };

    expect(dietPlan).toBeTruthy();
    expect(dietPlan.planName).toBe('Sample');

  });
});
