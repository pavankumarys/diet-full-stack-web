import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminaddplanComponent } from './components/adminaddplan/adminaddplan.component';
import { AdmineditplanComponent } from './components/admineditplan/admineditplan.component';
import { AdminnavComponent } from './components/adminnav/adminnav.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { AdminviewplanComponent } from './components/adminviewplan/adminviewplan.component';
import { AuthguardComponent } from './components/authguard/authguard.component';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { RequestedplanComponent } from './components/requestedplan/requestedplan.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { UserappliedplanComponent } from './components/userappliedplan/userappliedplan.component';
import { UsernavComponent } from './components/usernav/usernav.component';
import { UserplanformComponent } from './components/userplanform/userplanform.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { UserviewplanComponent } from './components/userviewplan/userviewplan.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AuthorizationInterceptor } from './interceptors/authorization.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    AdminaddplanComponent,
    AdmineditplanComponent,
    AdminnavComponent,
    AdminviewfeedbackComponent,
    AdminviewplanComponent,
    AuthguardComponent,
    ErrorComponent,
    HomeComponent,
    LoginComponent,
    NavbarComponent,
    RegistrationComponent,
    RequestedplanComponent,
    UseraddfeedbackComponent,
    UserappliedplanComponent,
    UsernavComponent,
    UserplanformComponent,
    UserviewfeedbackComponent,
    UserviewplanComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule  
  ],
  providers: [
    {provide:HTTP_INTERCEPTORS,useClass:AuthorizationInterceptor,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }