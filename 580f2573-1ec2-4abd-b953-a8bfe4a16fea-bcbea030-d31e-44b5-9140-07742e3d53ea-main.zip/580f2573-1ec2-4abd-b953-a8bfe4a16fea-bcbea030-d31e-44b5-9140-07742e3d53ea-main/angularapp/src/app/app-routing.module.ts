import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminnavComponent } from './components/adminnav/adminnav.component';
import { UsernavComponent } from './components/usernav/usernav.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { LoginComponent } from './components/login/login.component';
import { UserplanformComponent } from './components/userplanform/userplanform.component';
import { UserviewplanComponent } from './components/userviewplan/userviewplan.component';
import { HomeComponent } from './components/home/home.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { AdminaddplanComponent } from './components/adminaddplan/adminaddplan.component';
import { AdminviewplanComponent } from './components/adminviewplan/adminviewplan.component';
import { AdmineditplanComponent } from './components/admineditplan/admineditplan.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { RequestedplanComponent } from './components/requestedplan/requestedplan.component';
import { UserappliedplanComponent } from './components/userappliedplan/userappliedplan.component';
import { ErrorComponent } from './components/error/error.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  { path: 'usernav', component:UsernavComponent},
  { path: 'adminnav', component:AdminnavComponent},
  { path: "welcome", component:NavbarComponent },
  { path: "register", component:RegistrationComponent },
  { path: "login", component:LoginComponent },
  { path: "dietplanrequests", component:RequestedplanComponent,canActivate:[AuthGuard] },
  { path: "userviewplan", component:UserviewplanComponent,canActivate:[AuthGuard] },
  { path: "useraddplan", component:UserplanformComponent,canActivate:[AuthGuard] },
  { path: "home", component:HomeComponent },
  { path: "adddietplan", component:AdminaddplanComponent },
  { path: "viewdietplan", component:AdminviewplanComponent,canActivate:[AuthGuard] },
  { path: "editdietplan", component:AdmineditplanComponent,canActivate:[AuthGuard] },
  { path: "userappliedplan", component: UserappliedplanComponent,canActivate:[AuthGuard] },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {path:"feedback",component:UserviewfeedbackComponent,canActivate:[AuthGuard]},
  {path:"addfeedback",component:UseraddfeedbackComponent,canActivate:[AuthGuard]},
  {path:'adminfeedback',component:AdminviewfeedbackComponent,canActivate:[AuthGuard]},
  {path:"requestedplan",component:RequestedplanComponent,canActivate:[AuthGuard]},
  {path:"useraddfeedback",component:UseraddfeedbackComponent,canActivate:[AuthGuard]},
  {path:"adminviewfeedback",component:AdminviewfeedbackComponent,canActivate:[AuthGuard]},
  {path:"error",component:ErrorComponent},
  { path: '**', redirectTo: '/error' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }